// @flow
import React, { Component } from 'react';
import PropTypes from 'prop-types'

const DEFAULT_LINE_WIDTH = 4;
const DEFAULT_LINE_COLOR = 'black';

export type Coordinates = {
  x: number,
  y: number
}

export type Props = {
  lineColor: string,
  lineWidth: number,
  onDraw: (Coordinates) => void
};

export default class Draw extends Component {
  /*
  TODO: Implement drawing in Canvas using HTML5 DeviceMotion events

  This component should only process the acceleration data in the x and y axis only
  to produce suitable drawing coordinates. Computed drawing coordinates should only be within the
  current bounds of the canvas (i.e. current size)

  Canvas instance can be accessed via this.canvas

  */
  static propTypes = {
    lineColor: PropTypes.string,
    lineWidth: PropTypes.number
  }

  static defaultProps = {
    lineColor: DEFAULT_LINE_COLOR,
    lineWidth: DEFAULT_LINE_WIDTH
  };

  canvas: Object // Reference to canvas object
  hasDeviceMotion = window.DeviceMotionEvent;

  state: {
    drawingEnabled: boolean
  }

  componentWillMount() {
    if (this.hasDeviceMotion) {
      window.addEventListener('devicemotion', this.deviceMotion, false);
    }
  }

  componentWillUnmount() {
    if (this.hasDeviceMotion) {
      window.removeEventListener('devicemotion', this.deviceMotion, false);
    }
  }

  deviceMotion = (e: Event) => {
    // TODO:
    // 1. Implement logic to handle device motion event.
    // 2. Convert x,y acceleration data to suitable drawing coordinates.
    // 3. If drawing is enabled (i.e. this.state.drawingEnabled == true),
    //    draw on the canvas given the computed coordinates, using the current
    //    line width and color.
    // 4. Call this.props.onDraw to inform of current coordinates.

  }

  enable() {
    this.setState({drawingEnabled: true});
  }

  disable() {
    this.setState({drawingEnabled: false});
  }

  render() {
    // Remove unnecessary props before assigning to our canvas
    let {lineColor, lineWidth, ...rest} = this.props;

    return <canvas {...rest} ref={(item) => {this.canvas = item;}}/>
  }
}
